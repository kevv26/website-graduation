function generatequote() {
    const quotes = [
        { quote: "The best way to predict the future is to invent it.", author: "Alan Kay" },
        { quote: "Life is 10% what happens to us and 90% how we react to it.", author: "Charles R. Swindoll" },
        { quote: "Your time is limited, so don’t waste it living someone else’s life.", author: "Steve Jobs" },
        { quote: "The best way to get started is to quit talking and begin doing.", author: "Walt Disney" },
        { quote: "Don't let yesterday take up too much of today.", author: "Will Rogers" },
        { quote: "Dream big and dare to fail.", author: "Norman Vaughan" },
        { quote: "Dream big. Start small. Act now.", author: "Robin Sharma" },
        { quote: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
        { quote: "Genius is one percent inspiration and ninety-nine percent perspiration.", author: "Thomas Edison" },
        { quote: "Discipline equals freedom.", author: "Jocko Willink" },
        { quote: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
        { quote: "Winners never quit and quitters never win.", author: "Vince Lombardi" },
        { quote: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
        { quote: "The successful warrior is the average man, with laser-like focus.", author: "Bruce Lee" },
        { quote: "The secret of getting ahead is getting started.", author: "Mark Twain" },
        { quote: "When something is important enough, you do it even if the odds are not in your favor.", author: "Elon Musk" },
        { quote: "You will face many defeats in life, but never let yourself be defeated.", author: "Maya Angelou" },
        { quote: "It always seems impossible until it's done.", author: "Nelson Mandela" }
    ];
    
    const randomIndex = Math.floor(Math.random() * quotes.length);

    
    document.getElementById("quote").textContent = quotes[randomIndex].quote;
    document.getElementById("author").textContent = `- ${quotes[randomIndex].author}`;
}