#copy quote button code system = index.html (line 25-38)
import random
from flask import Response, Flask, render_template
from flask import jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("menu.html")

@app.route("/index.html")
def index():
    return render_template("index.html")

@app.route("/about.html")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    app.run(debug=True)
